import 'package:_food_delivery_ui_practice/modelos/pedido.dart';

class Usuario {
  final String nombre;
  final List<Pedido> pedidos;
  final List<Pedido> carta;

  Usuario({required this.nombre, required this.pedidos, required this.carta});
}
