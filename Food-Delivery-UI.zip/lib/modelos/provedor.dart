import 'package:_food_delivery_ui_practice/modelos/producto.dart';

class Provedor {
  final String imagenUrl;
  final String nombre;
  final String direccion;
  final double calificacion;
  final List<Producto> menu;

  Provedor(
      {required this.imagenUrl,
      required this.nombre,
      required this.direccion,
      required this.calificacion,
      required this.menu});
}
