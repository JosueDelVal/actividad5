import 'package:_food_delivery_ui_practice/modelos/producto.dart';
import 'package:_food_delivery_ui_practice/modelos/provedor.dart';

class Pedido {
  final Provedor provedor;
  final Producto producto;
  final String cita;
  final int cantidad;

  Pedido(
      {required this.provedor,
      required this.producto,
      required this.cita,
      required this.cantidad});
}
