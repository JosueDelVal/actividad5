class Producto {
  final String imagenURL;
  final String nombre;
  final double precio;

  Producto(
      {required this.imagenURL, required this.nombre, required this.precio});
}
