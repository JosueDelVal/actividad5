// Food

import 'package:_food_delivery_ui_practice/modelos/producto.dart';
import 'package:_food_delivery_ui_practice/modelos/pedido.dart';
import 'package:_food_delivery_ui_practice/modelos/provedor.dart';
import 'package:_food_delivery_ui_practice/modelos/usuario.dart';

final _libreta = Producto(
    imagenURL: "assets/images/img1.jpg", nombre: "Libretas", precio: 157.59);

final _borradores = Producto(
    imagenURL: "assets/images/img2.jpg",
    nombre: "Borradores Adorables ",
    precio: 5.99);

final _impresora = Producto(
    imagenURL: "assets/images/img3.jpg",
    nombre: "Impresora Canon",
    precio: 15700.99);

final _mochila = Producto(
    imagenURL: "assets/images/img4.jpeg",
    nombre: "Mochila pinguino",
    precio: 530.99);

final _hojas = Producto(
    imagenURL: "assets/images/img5.jpg",
    nombre: "Hojas de impresion",
    precio: 349.99);

final _borrador = Producto(
    imagenURL: "assets/images/img6.jpg", nombre: "Borrador", precio: 14.99);

final _sacapuntas = Producto(
    imagenURL: "assets/images/img7.jpg", nombre: "Sacapuntas", precio: 11.99);

final _lapiz = Producto(
    imagenURL: "assets/images/img8.jpg", nombre: "Lapiz", precio: 12.99);

// Restaurants

final _provedor1 = Provedor(
    imagenUrl: "assets/images/logo1.jpg",
    nombre: "PaperClip",
    direccion: "Santiago Troncoso/Bulevard Zaragoza",
    calificacion: 7.6,
    menu: [_libreta, _impresora, _mochila, _hojas, _borrador, _sacapuntas]);

final _provedor2 = Provedor(
    imagenUrl: "assets/images/logo2.jpg",
    nombre: "I love Paper",
    direccion: "Plaza de Las golondrina/Av.Mora7854",
    calificacion: 7.6,
    menu: [_libreta, _impresora, _hojas, _borrador, _sacapuntas, _lapiz]);

final _provedor3 = Provedor(
    imagenUrl: "assets/images/logo3.jpg",
    nombre: "Education Logo",
    direccion: "Eliseo Nava/78958",
    calificacion: 7.5,
    menu: [_borrador, _libreta, _borrador, _sacapuntas, _lapiz]);

final _provedor4 = Provedor(
    imagenUrl: "assets/images/logo4.jpg",
    nombre: "Marly",
    direccion: "Gabardina de la brigera/7618",
    calificacion: 7.5,
    menu: [_borrador, _impresora, _hojas, _lapiz]);

// Restaurants List

final List<Provedor> provedor = [
  _provedor1,
  _provedor2,
  _provedor3,
  _provedor4
];

// User

final usuarioActual = Usuario(nombre: "Zeeshan Ahmed", pedidos: [
  Pedido(
      provedor: _provedor2,
      producto: _libreta,
      cita: "Sep 30, 2022",
      cantidad: 50),
  Pedido(
      provedor: _provedor1,
      producto: _borradores,
      cita: "Sep 30, 2022",
      cantidad: 8),
  Pedido(
      provedor: _provedor3,
      producto: _lapiz,
      cita: "Sep 30, 2022",
      cantidad: 101),
  Pedido(
      provedor: _provedor4, producto: _hojas, cita: "Apr 30, 2022", cantidad: 1)
], carta: [
  Pedido(
      provedor: _provedor2,
      producto: _borrador,
      cita: "Sep 29, 2022",
      cantidad: 32),
  Pedido(
      provedor: _provedor2,
      producto: _impresora,
      cita: "Sep 30, 2022",
      cantidad: 5),
  Pedido(
      provedor: _provedor3,
      producto: _lapiz,
      cita: "Sep 30, 2022",
      cantidad: 15),
  Pedido(
      provedor: _provedor4,
      producto: _hojas,
      cita: "Sep 29, 2022",
      cantidad: 70),
  Pedido(
      provedor: _provedor1,
      producto: _borradores,
      cita: "Sep 30, 2022",
      cantidad: 28)
]);
